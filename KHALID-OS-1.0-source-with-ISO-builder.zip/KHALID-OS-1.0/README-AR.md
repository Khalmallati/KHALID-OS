# KHALID OS 1.0 — مشروع نظام تشغيل مبني على Debian

**المطور:** خالد الملاتي  
**الهدف:** نظام خفيف للحواسيب القديمة، بواجهة LXDE ومساعد هجين اختياري.

## مواصفات البناء
- الأساس: Debian 12 Bookworm (LTS حتى 30 يونيو 2028)
- المعمارية: i386 / 32-bit
- سطح المكتب: LXDE
- مدير الدخول: LightDM
- مدير النوافذ: Openbox
- وسيط الإخراج: Live ISO قابل للنسخ إلى USB

> تنبيه توافق: Debian 12 i386 يتطلب معالجاً من فئة i686. معالج Intel Atom N455 يدعم تعليمات 64-bit ويدعم عادةً متطلبات i686، لكن افحص الجهاز قبل التثبيت. Debian 13 لا يوفر نواة/مثبّت i386 رسميين.

## محتويات المشروع
- `auto/config`: إعداد live-build الأساسي.
- `config/package-lists/`: حزم النظام.
- `config/includes.chroot/`: ملفات وهوية KHALID OS داخل النظام الحي.
- `scripts/build-iso.sh`: بناء ISO.
- `scripts/check-host.sh`: فحص بيئة البناء.
- `ai/khalid-ai`: مساعد نصي هجين أولي (محلي + واجهة API متوافقة مع OpenAI).
- `config/includes.chroot/usr/share/applications/khalid-ai.desktop`: مشغل المساعد.

## متطلبات جهاز البناء
يفضل بناء ISO على حاسوب Linux بنظام Debian 12/13 **amd64** مع اتصال إنترنت ومساحة فارغة 15–25GB على الأقل. لا تبنِ ISO على الحاسوب المستهدف ذي RAM 1GB إن أمكن.

## الخطوة 1 — تجهيز جهاز البناء
من Debian/Ubuntu:
```bash
sudo apt update
sudo apt install -y live-build debootstrap squashfs-tools xorriso   isolinux syslinux-common syslinux-utils dosfstools mtools   git ca-certificates curl
```

## الخطوة 2 — فحص البيئة
```bash
cd KHALID-OS-1.0
chmod +x scripts/*.sh
./scripts/check-host.sh
```

## الخطوة 3 — بناء ISO
```bash
sudo ./scripts/build-iso.sh
```
سيكون الناتج في `../KHALID-OS-1.0-output/` إذا اكتمل البناء بنجاح.

## الخطوة 4 — نسخ ISO إلى USB
**تحذير: الأمر التالي يمسح USB بالكامل. تحقق من اسم الجهاز بعناية.**
```bash
lsblk
sudo dd if=../KHALID-OS-1.0-output/KHALID-OS-1.0-i386.iso of=/dev/sdX bs=4M status=progress conv=fsync
```
استبدل `/dev/sdX` باسم قرص USB كاملاً مثل `/dev/sdb`، وليس قسمًا مثل `/dev/sdb1`.

## مساعد KHALID AI
الوضع المحلي يقدم ردوداً أساسية دون إنترنت، وليس نموذجاً لغوياً كبيراً. للوضع السحابي:
1. انسخ `ai/.env.example` إلى `~/.config/khalid-ai/.env`.
2. أضف `BASE_URL` و`API_KEY` و`MODEL`.
3. لا تضع مفتاح API في ملفات ISO أو المستودع.
4. شغّل المساعد من قائمة التطبيقات.

مثال متغيرات:
```ini
BASE_URL=https://your-provider.example/v1
API_KEY=ضع_مفتاحك_محلياً
MODEL=your-model
```
البرنامج يستخدم واجهة `/chat/completions` المتوافقة مع OpenAI. قد تختلف إعدادات مزود الخدمة.

## ملاحظات مهمة
- هذا إصدار تأسيسي قابل للتطوير، وليس ISO جاهزاً أو مختبراً على جهازك بعد.
- `live-build` يحتاج تنزيل الحزم من مستودعات Debian؛ نجاح البناء يعتمد على اتصال الإنترنت وتوفر الحزم.
- لا تستخدم `dd` قبل التأكد من القرص الهدف.
- احتفظ بنسخة احتياطية من بياناتك قبل التثبيت.
