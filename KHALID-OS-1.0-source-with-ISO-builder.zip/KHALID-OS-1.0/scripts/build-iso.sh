#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
OUT="$ROOT/output"
mkdir -p "$OUT"
cd "$ROOT"
if [ "$(id -u)" -ne 0 ]; then
  echo "Run as root inside a Linux build environment."
  exit 1
fi
if ! command -v lb >/dev/null 2>&1; then
  echo "live-build is missing. See README-AR.md"
  exit 1
fi
chmod +x auto/config
lb clean --purge || true
lb config
lb build
ISO=$(find "$ROOT" -maxdepth 1 -type f -name '*.iso' -print -quit)
if [ -z "$ISO" ]; then
  echo "No ISO found. Inspect live-build.log and build logs."
  exit 2
fi
cp "$ISO" "$OUT/KHALID-OS-1.0-i386.iso"
sha256sum "$OUT/KHALID-OS-1.0-i386.iso" > "$OUT/SHA256SUMS"
echo "ISO ready: $OUT/KHALID-OS-1.0-i386.iso"
