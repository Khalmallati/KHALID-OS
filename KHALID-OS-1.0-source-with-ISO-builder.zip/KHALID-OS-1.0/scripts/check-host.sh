#!/bin/sh
set -eu
echo "KHALID OS build environment check"
for c in lb debootstrap xorriso mksquashfs; do
  if command -v "$c" >/dev/null 2>&1; then
    printf '[OK] %s: %s\n' "$c" "$(command -v "$c")"
  else
    printf '[MISSING] %s\n' "$c"
  fi
done
echo "Host architecture: $(dpkg --print-architecture 2>/dev/null || uname -m)"
echo "Free space:"
df -h .
